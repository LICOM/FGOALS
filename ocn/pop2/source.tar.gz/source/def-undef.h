#define NX_PROC 6
#define NY_PROC 2
#define SPMD
#define  SYNCH
#undef  FRC_ANN
#define CDFIN
#undef  FRC_DAILY
#undef  FRC_CORE
#define SOLAR
#define  ACOS
#undef  BIHAR
#undef  SMAG_FZ
#undef  SMAG_OUT
#define NETCDF
#define BOUNDARY
#define NODIAG
#undef  ICE
#undef SHOW_TIME
#undef DEBUG
#define COUP
#define  ISO
#define D_PRECISION
#define  CANUTO
#undef SOLARCHLORO
#undef LDD97
#define TSPAS
#undef  SMAG
#define JMT_GLOBAL 196
